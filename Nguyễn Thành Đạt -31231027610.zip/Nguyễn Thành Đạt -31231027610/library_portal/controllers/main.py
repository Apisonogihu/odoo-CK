from odoo import http
from odoo.http import request

class LibraryPortal(http.Controller):

    # 2.1 – Trang danh sách sách
    @http.route('/library/books', type='http', auth='public', website=True)
    def list_books(self, **kwargs):
        books = request.env['library.book'].sudo().search([('state', '=', 'available')])
        return request.render('library_portal.books_list_template', {
            'books': books
        })

    # 2.2 – Trang chi tiết sách
    @http.route('/library/book/<int:id>', type='http', auth='public', website=True)
    def book_detail(self, id, **kwargs):
        book = request.env['library.book'].sudo().browse(id)
        if not book.exists():
            return request.not_found()
        return request.render('library_portal.book_detail_template', {
            'book': book
        })

    # 2.3 – Form đăng ký mượn sách GET
    @http.route('/library/borrow/<int:id>', type='http', auth='public', website=True)
    def borrow_form(self, id, **kwargs):
        book = request.env['library.book'].sudo().browse(id)
        if not book.exists():
            return request.not_found()
        return request.render('library_portal.borrow_form_template', {
            'book': book,
            'error': kwargs.get('error'),
            'form_data': kwargs
        })

    # 2.3 – Form đăng ký mượn sách POST
    @http.route('/library/borrow/submit', type='http', auth='public', methods=['POST'], website=True, csrf=True)
    def borrow_submit(self, **post):
        book_id = post.get('book_id')
        name = post.get('name')
        email = post.get('email')
        phone = post.get('phone')

        if not name or not email or '@' not in email:
            book = request.env['library.book'].sudo().browse(int(book_id))
            return request.render('library_portal.borrow_form_template', {
                'book': book,
                'error': "Vui lòng nhập họ tên và một email hợp lệ (có chứa @).",
                'form_data': post
            })

        request_val = {
            'name': name,
            'email': email,
            'phone': phone,
            'book_id': int(book_id),
        }
        borrow_req = request.env['library.borrow.request'].sudo().create(request_val)
        return request.redirect(f'/library/borrow/thank-you?req_id={borrow_req.id}')

    @http.route('/library/borrow/thank-you', type='http', auth='public', website=True)
    def borrow_thank_you(self, **kwargs):
        req_id = kwargs.get('req_id')
        return request.render('library_portal.thank_you_template', {
            'req_id': req_id
        })

    # 3.1 – API lấy danh sách sách
    @http.route('/api/library/books', type='json', auth='public')
    def api_list_books(self, **kwargs):
        books = request.env['library.book'].sudo().search([('state', '=', 'available')])
        return [{
            'id': b.id,
            'name': b.name,
            'author': b.author,
            'quantity': b.quantity
        } for b in books]

    # 3.2 – API tạo borrow request
    @http.route('/api/library/borrow', type='json', auth='public', methods=['POST'])
    def api_borrow_request(self, name=None, email=None, phone=None, book_id=None, **kwargs):
        if not book_id:
            return {"success": False, "error": "Thiếu book_id."}
        
        book = request.env['library.book'].sudo().browse(int(book_id))
        if not book.exists() or book.quantity <= 0:
            return {"success": False, "error": "Sách không tồn tại hoặc đã hết số lượng."}

        if not email or '@' not in email or not name:
            return {"success": False, "error": "Tên và Email hợp lệ là bắt buộc."}

        req = request.env['library.borrow.request'].sudo().create({
            'name': name,
            'email': email,
            'phone': phone,
            'book_id': book.id
        })
        return {"success": True, "request_id": req.id}

    # 3.3 – API yêu cầu đăng nhập
    @http.route('/api/library/my-requests', type='json', auth='user')
    def api_my_requests(self, **kwargs):
        user_email = request.env.user.email
        if not user_email:
            return []
        
        requests = request.env['library.borrow.request'].search([('email', '=', user_email)])
        return [{
            'id': r.id,
            'name': r.name,
            'book_id': r.book_id.id,
            'book_name': r.book_id.name,
            'state': r.state,
            'request_date': r.request_date
        } for r in requests]
